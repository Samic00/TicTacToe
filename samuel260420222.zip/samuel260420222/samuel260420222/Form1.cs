﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace samuel260420222
{
    public partial class Form1 : Form
    {
        char[] a = new char[2];
        int a1 = 0;
        private Socket s;
        public Form1()
        {
            InitializeComponent();
            MessageReciever.DoWork += MessageReciever_DoWork;
            CheckForIllegalCrossThreadCalls = false;
            a[0] = 'x';
            a[1] = 'o';
            TcpListener server = null;
            IPAddress localAddr = IPAddress.Parse("127.0.0.1");
            try
            {
                Int32 port = 5000;
                server = new TcpListener(localAddr, port);
                server.Start();
                s = server.AcceptSocket();

            }
            catch
            {

            }
        }
        private void MessageReciever_DoWork(object sender, DoWorkEventArgs e)
        {
            if (provjera())
            {
                return;
            }
            Freeze();
            primaj();
            if (!provjera())
            {
                UnFreeze();
            }
        }

        private BackgroundWorker MessageReciever = new BackgroundWorker();
        
        private void Freeze()
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
        }
        private void UnFreeze()
        {
            if (button1.Text.ToString() == "")
            {
                button1.Enabled = true;
            }
            if (button2.Text.ToString() == "")
            {
                button2.Enabled = true;
            }
            if (button3.Text.ToString() == "")
            {
                button3.Enabled = true;
            }
            if (button4.Text.ToString() == "")
            {
                button4.Enabled = true;
            }
            if (button5.Text.ToString() == "")
            {
                button5.Enabled = true;
            }
            if (button6.Text.ToString() == "")
            {
                button6.Enabled = true;
            }
            if (button7.Text.ToString() == "")
            {
                button7.Enabled = true;
            }
            if (button8.Text.ToString() == "")
            {
                button8.Enabled = true;
            }
            if (button9.Text.ToString() == "")
            {
                button9.Enabled = true;
            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            byte[] num = { 1 };
            s.Send(num);
            char c;
            a1++;
            if (a1 % 2 == 0)
            {
                c = a[1];
            }
            else
            {
                c = a[0];
            }
            button1.Text = c.ToString();
            MessageReciever.RunWorkerAsync();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            byte[] num = { 2 };
            s.Send(num);
            char c;
            a1++;
            if (a1 % 2 == 0)
            {
                c = a[1];
            }
            else
            {
                c = a[0];
            }
            button2.Text = c.ToString();
            MessageReciever.RunWorkerAsync();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            byte[] num = { 3 };
            s.Send(num);
            char c;
            a1++;
            if (a1 % 2 == 0)
            {
                c = a[1];
            }
            else
            {
                c = a[0];
            }
            button3.Text = c.ToString();
            MessageReciever.RunWorkerAsync();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            byte[] num = { 4 };
            s.Send(num);
            char c;
            a1++;
            if (a1 % 2 == 0)
            {
                c = a[1];
            }
            else
            {
                c = a[0];
            }
            button4.Text = c.ToString();
            MessageReciever.RunWorkerAsync();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            byte[] num = { 5 };
            s.Send(num);
            char c;
            a1++;
            if (a1 % 2 == 0)
            {
                c = a[1];
            }
            else
            {
                c = a[0];
            }
            button5.Text = c.ToString();
            MessageReciever.RunWorkerAsync();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            byte[] num = { 6 };
            s.Send(num);
            char c;
            a1++;
            if (a1 % 2 == 0)
            {
                c = a[1];
            }
            else
            {
                c = a[0];
            }
            button6.Text = c.ToString();
            MessageReciever.RunWorkerAsync();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            byte[] num = { 7 };
            s.Send(num);
            char c;
            a1++;
            if (a1 % 2 == 0)
            {
                c = a[1];
            }
            else
            {
                c = a[0];
            }
            button7.Text = c.ToString();
            MessageReciever.RunWorkerAsync();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            byte[] num = { 8 };
            s.Send(num);
            char c;
            a1++;
            if (a1 % 2 == 0)
            {
                c = a[1];
            }
            else
            {
                c = a[0];
            }
            button8.Text = c.ToString();
            MessageReciever.RunWorkerAsync();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            byte[] num = { 9 };
            s.Send(num);
            char c;
            a1++;
            if (a1 % 2 == 0)
            {
                c = a[1];
            }
            else
            {
                c = a[0];
            }
            button9.Text = c.ToString();
            MessageReciever.RunWorkerAsync();
        }
        bool provjera()
        {
            int a5 = 0;
            label1.Text = a5.ToString();
            if (button1.Text == "x" && button2.Text == "x" && button3.Text == "x")
            {
                label1.Text = "Pobjedio je x";
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                return true;
            }
            else if (button4.Text == "x" && button5.Text == "x" && button6.Text == "x")
            {
                label1.Text = "Pobjedio je x";
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                return true;
            }
            else if (button7.Text == "x" && button8.Text == "x" && button9.Text == "x")
            {
                label1.Text = "Pobjedio je x";
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                return true;
            }
            else if (button1.Text == "x" && button5.Text == "x" && button9.Text == "x")
            {
                label1.Text = "Pobjedio je x";
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                return true;
            }
            else if (button3.Text == "x" && button5.Text == "x" && button7.Text == "x")
            {
                label1.Text = "Pobjedio je x";
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                return true;
            }
            else if (button1.Text == "x" && button4.Text == "x" && button7.Text == "x")
            {
                label1.Text = "Pobjedio je x";
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                return true;
            }
            else if (button2.Text == "x" && button5.Text == "x" && button8.Text == "x")
            {
                label1.Text = "Pobjedio je x";
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                return true;
            }
            else if (button3.Text == "x" && button6.Text == "x" && button9.Text == "x")
            {
                label1.Text = "Pobjedio je x";
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                return true;
            }
            if (button1.Text == "o" && button2.Text == "o" && button3.Text == "o")
            {
                label1.Text = "Pobjedio je o";
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                return true;
            }
            else if (button4.Text == "o" && button5.Text == "o" && button6.Text == "o")
            {
                label1.Text = "Pobjedio je o";
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                return true;
            }
            else if (button7.Text == "o" && button8.Text == "o" && button9.Text == "o")
            {
                label1.Text = "Pobjedio je o";
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                return true;
            }
            else if (button1.Text == "o" && button5.Text == "o" && button9.Text == "o")
            {
                label1.Text = "Pobjedio je o";
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                return true;
            }
            else if (button3.Text == "o" && button5.Text == "o" && button7.Text == "o")
            {
                label1.Text = "Pobjedio je o";
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                return true;
            }
            else if (button1.Text == "o" && button4.Text == "o" && button7.Text == "o")
            {
                label1.Text = "Pobjedio je o";
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                return true;
            }
            else if (button2.Text == "o" && button5.Text == "o" && button8.Text == "o")
            {
                label1.Text = "Pobjedio je o";
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                return true;
            }
            else if (button3.Text == "o" && button6.Text == "o" && button9.Text == "o")
            {
                label1.Text = "Pobjedio je o";
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                return true;
            }
            else if (!(button1.Text == "") && !(button2.Text == "") && !(button3.Text == "") && !(button4.Text == "") && !(button5.Text == "") && !(button6.Text == "") && !(button7.Text == "") && !(button8.Text == "") && !(button9.Text == ""))
            {
                return true;
            }
            return false;
        }
        private void primaj()
        {
            byte[] buffer = new byte[1];
            s.Receive(buffer);
            if (buffer[0] == 1)
            {
                char c;
                a1++;
                if (a1 % 2 == 0)
                {
                    c = a[1];
                }
                else
                {
                    c = a[0];
                }
                button1.Text = c.ToString();
            }
            else if (buffer[0] == 2)
            {
                char c;
                a1++;
                if (a1 % 2 == 0)
                {
                    c = a[1];
                }
                else
                {
                    c = a[0];
                }
                button2.Text = c.ToString();
            }
            else if (buffer[0] == 3)
            {
                char c;
                a1++;
                if (a1 % 2 == 0)
                {
                    c = a[1];
                }
                else
                {
                    c = a[0];
                }
                button3.Text = c.ToString();
            }
            else if (buffer[0] == 4)
            {
                char c;
                a1++;
                if (a1 % 2 == 0)
                {
                    c = a[1];
                }
                else
                {
                    c = a[0];
                }
                button4.Text = c.ToString();
            }
            else if (buffer[0] == 5)
            {
                char c;
                a1++;
                if (a1 % 2 == 0)
                {
                    c = a[1];
                }
                else
                {
                    c = a[0];
                }
                button5.Text = c.ToString();
            }
            else if (buffer[0] == 6)
            {
                char c;
                a1++;
                if (a1 % 2 == 0)
                {
                    c = a[1];
                }
                else
                {
                    c = a[0];
                }
                button6.Text = c.ToString();
            }
            else if (buffer[0] == 7)
            {
                char c;
                a1++;
                if (a1 % 2 == 0)
                {
                    c = a[1];
                }
                else
                {
                    c = a[0];
                }
                button7.Text = c.ToString();
            }
            else if (buffer[0] == 8)
            {
                char c;
                a1++;
                if (a1 % 2 == 0)
                {
                    c = a[1];
                }
                else
                {
                    c = a[0];
                }
                button8.Text = c.ToString();
            }
            else if (buffer[0] == 9)
            {
                char c;
                a1++;
                if (a1 % 2 == 0)
                {
                    c = a[1];
                }
                else
                {
                    c = a[0];
                }
                button9.Text = c.ToString();
            }

        }
    }
}